
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.Toolkit;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Vector;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.BorderLayout;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Cupo y Arturo
 */
public class BreakingBad extends JFrame implements Runnable, KeyListener {

    private static final long serialVersionUID = 1L;
    // Se declaran las variables.
    private int iDir;    // Direccion del elefante
    private int iX;    // Incremento en x
    private int iY;    // Incremento en y
    private int iVidas;    // vidas del applet
    private int iScore;   // el puntaje de usuario.
    private final int MIN = -5;    //Minimo numero al generar un numero al azar.
    private final int MAX = 6;    //Maximo numero al generar un numero al azar.
    private static final int WIDTH = 1000;    //Ancho del JFrame.
    private static final int HEIGHT = 600;    //Alto del JFrame.
    private Image imaDbImage;    // Imagen a proyectar
    private Image imaDgameover;    // Imagen al finalizar el juego.
    private Image imaPaused;    //Imagen al pausar el juego.
    private Graphics dbg;	// Objeto grafico
    private SoundClip scSonido;    // Objeto SoundClip
    private SoundClip scBomb;    //Objeto SoundClip
    private SoundClip scMusica;    //musica de fondo
    private Animacion animPelota;   // animacion de la pelota 
    private Animacion animRaton;
    private Vector<Puntaje> vec;    //Objeto vector.
    private String nombreArchivo;    //Nombre del archivo.
    private String[] arr;    //Arreglo para agregar  el contenido dividido del archivo
    private boolean bPause;    //Boleano para pausar el juego.
    private JFrame jframeScore;    //Frame para desplegar el puntaje.
    private JList listaScore;    //Lista para desplegar el puntaje.
    private long tiempoActual;

    public BreakingBad() {
        bPause = false;
        nombreArchivo = "Puntaje.txt";
        vec = new Vector<Puntaje>();
        iScore = 0;
        iVidas = 10;    // Le asignamos un valor inicial al vidas
        iDir = -1;    // No se mueve 
        int iX = (int) (Math.random() * (WIDTH / 4));    // posicion en x 
        int iY = (int) (Math.random() * (HEIGHT / 4));    // posicion en y 
        setTitle("BreakingBad");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 600);
        setVisible(true);
        	scMusica = new SoundClip("bbad.wav");
		//scBomb = new SoundClip("Explosion.wav");
		//Se cargan las imagenes.
		//imaPaused = Toolkit.getDefaultToolkit().
                  //      getImage(this.getClass().getResource("gameover.jpg"));
		//imaDgameover = Toolkit.getDefaultToolkit().
                  //      getImage(this.getClass().getResource("pause.jpg"));	
		//Musica de fondo
		scMusica.setLooping(true);
		scMusica.play();
		// Declaras un hilo
		Thread t = new Thread (this);
		// Empieza el hilo
		t.start ();
	}
        
    

    @Override
    public void run() {

    }

    @Override
    public void keyTyped(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyPressed(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyReleased(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
