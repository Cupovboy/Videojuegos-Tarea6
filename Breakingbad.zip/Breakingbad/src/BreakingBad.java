
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.Toolkit;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Vector;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.BorderLayout;
import java.net.URL;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Cupo y Arturo
 */
public class BreakingBad extends JFrame implements Runnable, KeyListener {

    private static final long serialVersionUID = 1L;
    // Se declaran las variables.
    private int iVel;       // Direccion del elefante
    private int iX;         // Incremento en x
    private int iY;         // Incremento en y
    private int iVidas;     // vidas del applet
    private int iScore;     // el puntaje de usuario.
    private int iOption;    //Estado de la flecha selectora
    private boolean bPause;             //Boleano para pausar el juego.
    private boolean bMenu;              //Boleana de esado de menu
    private final int MIN = -5;         //Minimo numero al generar un numero al azar.
    private final int MAX = 6;          //Maximo numero al generar un numero al azar.
    private static final int WIDTH = 1000;    //Ancho del JFrame.
    private static final int HEIGHT = 600;    //Alto del JFrame.
    
    private Image imagameover;      //Imagen al finalizar el juego.
    private Image imaPaused;        //Imagen al pausar el juego.
    private Image imaBackground;    //Imagen de fondo
    private SoundClip scSonido;     // Objeto SoundClip
    private SoundClip scBomb;       //Objeto SoundClip
    private SoundClip scMusica;     //musica de fondo
    private Animacion animPelota;   // animacion de la pelota 
    private Animacion animRaton;
    private Vector<Puntaje> vec;    //Objeto vector.
    private String nombreArchivo;   //Nombre del archivo.
    private String[] arr;           //Arreglo para agregar  el contenido dividido del archivo
    
    private JFrame jframeScore;     //Frame para desplegar el puntaje.
    private JList listaScore;       //Lista para desplegar el puntaje.
    private long tiempoActual;
    
    // Variables para el doubleBuffer
    private Image imaDbImage;       // Imagen a proyectar.
    private Graphics dbg;           // Objeto grafico.

    public BreakingBad() {
        //Configuracion del Jframe
        setTitle("BreakingBad");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 600);
        setVisible(true);
        
        bPause = false;
        bMenu = true;
        nombreArchivo = "Puntaje.txt";
        vec = new Vector<Puntaje>();
        iScore = 0;
        iVidas = 10;    // Le asignamos un valor inicial al vidas
        iVel = 0;    // No se mueve 
        iOption = 0;
        iX = this.getSize().width/2 - 75;    // posicion en x 
        iY = this.getSize().height - 60;    // posicion en y 
        
        scMusica = new SoundClip("bbad.wav");
        imaBackground = Toolkit.getDefaultToolkit().
                getImage(this.getClass().getResource("Background.png"));
        //scBomb = new SoundClip("Explosion.wav");
        //Se cargan las imagenes.
        //imaPaused = Toolkit.getDefaultToolkit().
          //      getImage(this.getClass().getResource("gameover.jpg"));
        //imaDgameover = Toolkit.getDefaultToolkit().
          //      getImage(this.getClass().getResource("pause.jpg"));	
        //Musica de fondo
        scMusica.setLooping(true);
        scMusica.play();
        
        addKeyListener(this);
        // Declaras un hilo
        Thread t = new Thread (this);
        // Empieza el hilo
        t.start ();
	}
        
    public void run () {
        while (iVidas > 0)
        {
            if(!bPause) {
                // Actualizas la coordenada en x
                actualiza();
                checaColision();
            }
            // Se actualiza el <code>Applet</code> repintando el contenido
            repaint();

            try	{
                // El thread se duerme
                Thread.sleep(20);
            }
            catch (InterruptedException ex)	{
                System.out.println("Error en " + ex.toString());
            }
        }
    }
    
    /**
     * Metodo actualiza que recalcula todas las variables despues de cada tick
     * 
     */
    public void actualiza() {
        iX += iVel;
    }
    
    /**
     * Metodo checaColision que reacciona ante una colision con alguna pared
     * o tambien maneja colisiones entre objetos
     */
    public void checaColision() {
        
    }// fin de checaColision
    
    /**
     * Metodo update que se encarga del double Buffering
     * @param g 
     */
    public void paint(Graphics g) {
        // Inicializan el DoubleBuffer
        if (imaDbImage == null){ 
            imaDbImage = createImage(this.getSize().width, this.getSize().height);
            dbg = imaDbImage.getGraphics();
        }
        // Actualiza la imagen de fondo
        dbg.drawImage(imaBackground, 0, 0, this.getSize().width,this.getSize().height, this);
        // Actualiza el Foreground
        dbg.setColor(getForeground());
        paint1(dbg);
        // Dibuja la imagen actualizada y con esto ya no se ve parpadeo
        g.drawImage(imaDbImage, 0, 0, this);
    }
    
    /**
     * Metodo <I>paint</I> sobrescrito de la clase <code>Applet</code>,
     * heredado de la clase Container.<P>
     * En este metodo se dibuja la imagen con la posicion actualizada,
     * ademas que cuando la imagen es cargada te despliega una advertencia.
     * @param g es el <code>objeto grafico</code> usado para dibujar.
     */
    public void paint1(Graphics g) {
        if(bMenu) {
            g.setColor(Color.white);
            g.fillRect(300, 100, 600, 400);
            g.setColor(Color.black);
            if(iOption == 0) {
                int i1[]={430,430,450},i2[]={240,260,250};
                g.fillPolygon( i1, i2, 3);
            }
            else {
                int i1[]={430,430,450},i2[]={300,320,310};
                g.fillPolygon(i1, i2, 3);
            }
        }
        else if(bPause) {
            g.setColor(Color.red);
            g.fillRect(300, 100, 600, 400);
            g.setColor(Color.blue);
            if(iOption == 0) {
                int i1[]={430,430,450},i2[]={240,260,250};
                g.fillPolygon( i1, i2, 3);
            }
            else {
                int i1[]={430,430,450},i2[]={300,320,310};
                g.fillPolygon(i1, i2, 3);
            }
        }
        else {
            g.setColor(Color.blue);
            g.fillRect(iX , iY, 150, 30);
        }
        g.drawString("bMenu: "+bMenu+" bPause: "+iVel, 50, 50);
    }//fin de paint1
    
    /**
     * Metodo main
     * args es un arreglo de tipo String de linea de comandos
     * @param args
     */
    public static void main(String[] args){
        BreakingBad BBad = new BreakingBad();
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent ke) {
        if(bMenu || bPause) {
            if(ke.getKeyCode() == KeyEvent.VK_DOWN && iOption == 0) {
                iOption++;
            }
            if(ke.getKeyCode() == KeyEvent.VK_UP && iOption == 1) {
                iOption--;
            }
        }
        if(bMenu) {
            if(ke.getKeyCode() == KeyEvent.VK_ENTER ){
                if(iOption == 0) {
                    bMenu = false;
                }
                else {
                    System.exit(0);
                }
            }
        }
        else if(bPause) {
            if(ke.getKeyCode() == KeyEvent.VK_ENTER ){
                bPause = false;
                if(iOption == 1) {
                    bMenu = true;
                    iOption = 0;
                }
            }
        }
        else {
            if(ke.getKeyCode() == KeyEvent.VK_P) {
                bPause = true;
                iOption = 0;
            }
            if(ke.getKeyCode() == KeyEvent.VK_RIGHT) {
                iVel = 5;
            }
            if(ke.getKeyCode() == KeyEvent.VK_LEFT) {
                iVel = -5;
            }
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        iVel = 0;
    }
}
